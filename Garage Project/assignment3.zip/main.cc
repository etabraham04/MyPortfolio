#include "Control.h"

int main(){
    Control control;
    control.launch();
    return 0;
}