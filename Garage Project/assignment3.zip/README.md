## Program Author:

-   Name: Ethan Abraham
-   Student Number: 101324864

## List of Source Files:

-   Car.cc: the Car class
-   Control.cc: given
-   Customer.cc: the Customer class based on Entity
-   Entity.cc: the Entity abstract class
-   Garage.cc: the Garage class
-   main.cc: given
-   Mechanic.cc: the mechanic class based on entity
-   Repair.cc: the repair class
-   RepairList.cc: the repairlist class that stores repairs
-   test.cc: giver
-   TestControl: given
-   Tester.cc: given
-   View.cc: given

## List of Header Files:

-   Car.h: the Car class
-   Control.h: given
-   Customer.h: the Customer class based on Entity
-   Entity.h: the Entity abstract class
-   Garage.h: the Garage class
-   Mechanic.h: the mechanic class based on entity
-   Repair.h: the repair class
-   RepairList.h: the repairlist class that stores repairs
-   TestControl.h: given
-   Tester.h: given
-   View.h: given

## Compilation and Launch Instructions:

### Compilation:

-   To compile, enter `make` into a terminal open in the source file directory.
-   The make file should compile everything required

### Launch:

-   To launch the compiled code, enter `./a3` into the same termional in the same directory
-   To launch the testing suit, enter `./a3test` into the terminal like above

## Differences to the Specification

-   added n to count size for the repair list

## Libraries Used:

```C++
#include <iostream>
#include <string>
#include <iomanip>
#include <vector>
```
